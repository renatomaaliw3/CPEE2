<?php

	function bindDropdown($sql, $value, $description) {

		global $conn;

		$stmt = $conn->prepare($sql);

		$stmt->execute();

		$output = '';

		while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {

			$output .= "<option value='{$result[$value]}'>" . $result[$description] . "</option>";

		}

		return $output;

	}

	function redirect_to($location) {

		header("Location: " . $location);

	}
	

?>