var request = null;
$(document).ready(function() {

	$('#employee-table').load('ajax/load_table.php');

	$('#search').on('keyup', function() {

		var search = $(this).val();

		if (request) {

			clearTimeout(request);

		}

		request = setTimeout(function() {

			$.ajax({

				method: 'POST',
				url: 'ajax/load_search.php',
				data: {search : search},
				success: function(data) {

					$('#employee-table').html(data);
					request = null;

				}

			});

		}, 1000);

	});

});