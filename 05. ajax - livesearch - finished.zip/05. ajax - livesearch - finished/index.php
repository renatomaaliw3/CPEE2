<?php 

	include('connection.php');
	include('include/functions.php');

?>
<!DOCTYPE html>
<html>
	<head>
		<title> Simple CRUD Application (Dropdown, Radio) </title>
		<link rel="stylesheet" href="css/styles.css">
	</head>
<body>

	<div id="wrapper">

		<form action="add.php" method="post">
			
			<fieldset>
				<legend> Add Record </legend>
				<div>
					<label for="lastname"> Last Name </label>
					<input type="text" name="lastname" id="lastname" required>
				</div>
				<div>
					<label for="middlename"> Middlename </label>
					<input type="text" name="middlename" id="middlename" required>
				</div>
				<div>
					<label for="firstname"> First Name </label>
					<input type="text" name="firstname" id="firstname" required>
				</div>
				<div>
					<label for="sex"> Sex </label>
					<p>
						<input type="radio" name="sex" value="Male" checked required><span> Male </span>
						<input type="radio" name="sex" value="Female" required><span> Female </span>
					</p>
				</div>
				<div>
					<label for="department"> Department </label>
					<select name="departmentid" id="departmentid" required>
						
						<?php 

							$sql = "SELECT * FROM tbldepartment ORDER BY department ";
							echo bindDropdown($sql, 'departmentid', 'department'); 

						?>

					</select>
				</div>
				<div>
					<label for=""> &nbsp;</label>
					<input type="submit" value="CREATE" name="create">
				</div>

			</fieldset>
			
		</form>

		<hr>

		<form id="live-search" class="mt-1 d-block">
		
			<div>
				<label for="search"> Search </label>
				<input type="text" name="search" id="search" placeholder="Enter Search String" style="width: 45%;">
			</div>

		</form>

		<div id="employee-table">
			
			<!-- DATA WILL BE LOADED THROUGH AJAX -->

		</div>

	</div>

</body>
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/main.js"></script>
</html>