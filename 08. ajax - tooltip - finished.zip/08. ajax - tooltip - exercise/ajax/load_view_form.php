<?php  

	include_once('../connection.php');
	include_once('../include/functions.php');

	$employeeid = $_GET['employeeid'];

	$sql = "SELECT * FROM tblemployees ";

		$sql .= " INNER JOIN tbldepartment ON ";
		$sql .= " tblemployees.departmentid = tbldepartment.departmentid ";

		$sql .= " INNER JOIN tblprogram ON ";
		$sql .= " tblemployees.programid = tblprogram.programid ";

	$sql .= " WHERE employeeid = :employeeid ";

	$result = fetch_single_row($sql, 'employeeid', $employeeid);

?>	

<div class="info">

			<div class="profile-info">
			
				<span class="close"> X </span>
			
				<div class="profile-info-picture">
				
					<figure style="background-image: url(

					<?php 

						if ($result['photo'] == '') { 

							echo 'img/nophoto.jpg'; 

						} else { 

							echo 'upload/' . $result['photo']; 
							
						} 

					?>
					
					)">
							
					</figure>

				</div>

				<div class="profile-info-details">
					
					<h2><?php echo $result['firstname'] . " " . $result['middlename'] . " " . $result['lastname']; ?> </h2>
					<h4><?php echo $result['department']; ?></h4>
					<h5><em><?php echo $result['program']; ?></em></h5>

				</div>

				<div>

					<form id="upload-form" method="post" enctype="multipart/form-data" action="upload.php?employeeid=<?php echo $employeeid;?>">

						<div>
							<h4> Upload Photo </h4>
							<input type="file" name="photo" id="photo" accept="image/jpeg, image/png" required>
						</div>
						<div class="mt-1">
							<input type="submit" name="upload-btn" id="upload-btn" value="Upload">
						</div>

					</form>

				</div>

			</div>

</div>