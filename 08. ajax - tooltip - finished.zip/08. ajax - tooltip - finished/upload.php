<?php

	include_once('connection.php');
	include_once('include/functions.php');

	$employeeid = $_GET['employeeid'];

	/* UPLOADING FILES */

	// 01. Directory for Upload
	// 02. Temporary Name of File ['tmp_name']
	// 03. Base Name of Files ['name']
	// 04. PHP Upload Function move_uploaded_file(Temporary File Name, Destination)

	/* 05. 	Possible Improvements
	     	pathinfo(basename, PATHINFO_EXTENSION)
	       	rand(min, max)
	       	uniqid(target, true);

	*/

	$dir = 'upload/';
	$temp_name = $_FILES['photo']['tmp_name'];
	$base_name = basename($_FILES['photo']['name']);

	$file_extension = pathinfo($base_name, PATHINFO_EXTENSION);

	$random_number = rand(1, 1000000000);

	$random_name = uniqid($random_number, true);

	$new_file_name = $random_name . $random_number . "." . $file_extension;

	move_uploaded_file($temp_name, $dir . $new_file_name);

	$post_data = array('photo' => $new_file_name);

	execute_query('tblemployees', $post_data, 'update', 'employeeid', $employeeid);

	redirect_to('index.php');

?>