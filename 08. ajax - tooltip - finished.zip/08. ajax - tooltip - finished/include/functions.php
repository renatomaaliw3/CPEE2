<?php

	//BIND DATA TO DROPDOWN MENU (BIND FOR UPDATE TOO)

	function bindDropdown($sql, $value, $description, $identifier = NULL) {

		global $conn;

		$stmt = $conn->prepare($sql);

		$stmt->execute();

		$output = '';

		while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {

			$output .= "<option value='{$result[$value]}' ";

				if ($result[$value] == $identifier) {

					$output .= " selected ";

				}


			$output .= ">" . $result[$description] . "</option>";

		}

		return $output;

	}

	//REDIRECT TO SPECIFIED PAGE

	function redirect_to($location) {

		header("Location: " . $location);

	}

	//ABSTRACTION (PARTIAL) OF CREATE, UPDATE, DELETE

	function execute_query($table_name, $post_data = NULL, $mode = 'create', $pk = NULL, $pk_value = NULL) {

		global $conn;

		$sql = getSQLString($table_name, $post_data, $mode, $pk);

		$stmt = $conn->prepare($sql);

		if ($mode == 'create' || $mode == 'update') {

			foreach ($post_data as $key => $value) { //post bind

				bindTokens($stmt, $key, $value);

			}

		}

		if ($mode == 'update' || $mode == 'delete') { //get bind

			bindTokens($stmt, $pk, $pk_value);

		}

		$stmt->execute();

	}

		function getDBFields($post_data) {

			$sql = implode(', ', array_keys($post_data)); //array -> string

			return $sql;

		}

		function getTokens($post_data, $mode) {

			$new_array = array(); //define blank array

			$output = '';

			switch ($mode) {

				case 'create':

					foreach ($post_data as $key => $value) {

						array_push($new_array, ":" . $key);

					}

				break;

				case 'update':

					foreach ($post_data as $key => $value) {

						array_push($new_array, $key . " = :" . $key);

					}

				break;

			}

			$output = implode(', ', $new_array);

			return $output;

		}

		function bindTokens($stmt, $key, $value) {

			return $stmt->bindParam(":" . $key, $value, PDO::PARAM_STR);

		}

		function getSQLString($table_name, $post_data, $mode = 'create', $pk = NULL) {

			$sql = '';

			switch ($mode) {

				case 'create':

					$sql = "INSERT INTO {$table_name} (" . getDBFields($post_data) . ") VALUES (" . getTokens($post_data, 'create') . ")";

				break;


				case 'update':

					$sql = "UPDATE {$table_name} SET " . getTokens($post_data, 'update') . " WHERE {$pk} = :{$pk}";

				break;

				case 'delete':

					$sql = "DELETE FROM {$table_name} WHERE {$pk} = :{$pk}";

				break;

			}

			return $sql;

		}


	function fetch_all_rows($sql) {

		global $conn;

		$stmt = $conn->prepare($sql);

		$stmt->execute();

		return $stmt->fetchAll();

	}

	function fetch_single_row($sql, $key, $value) {

		global $conn;

		$stmt = $conn->prepare($sql);

		bindTokens($stmt, $key, $value);

		$stmt->execute();

		return $stmt->fetch(PDO::FETCH_ASSOC);

	}

	function count_rows($sql) {

		global $conn;

		$stmt = $conn->prepare($sql);

		$stmt->execute();

		return $stmt->rowCount();

	}
?>