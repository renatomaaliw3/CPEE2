<?php

	include('connection.php');
	include('include/functions.php');

	//Insert Data Here

	if (isset($_POST['create'])) {

		array_pop($_POST); //remove 'create' post
		
		execute_query('tblemployees', $_POST);

		redirect_to('index.php');

	}

?>