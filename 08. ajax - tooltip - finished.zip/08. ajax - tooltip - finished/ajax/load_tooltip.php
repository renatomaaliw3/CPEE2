<?php

	include_once('../connection.php');
	include_once('../include/functions.php');

	$employeeid = $_POST['employeeid'];
	
	$sql = "SELECT * FROM tblemployees WHERE employeeid = :employeeid ";

	$result = fetch_single_row($sql, 'employeeid', $employeeid);


	if ($result['photo'] == '') {

		echo "<p class='tooltip' style='background-image: url(img/nophoto.jpg)'></p>";

	} else {

		echo "<p class='tooltip' style='background-image: url(upload/" . $result['photo'] . ")'></p>";

	}

	

?>