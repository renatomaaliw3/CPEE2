<?php

	include_once('../connection.php');
	include_once('../include/functions.php');

	$departmentid = $_POST['departmentid'];
	
	$sql = "SELECT * FROM tbldepartment ";
	$sql .= " INNER JOIN tblprogram ON ";
	$sql .= " tbldepartment.departmentid = tblprogram.departmentid ";
	$sql .= " WHERE tblprogram.departmentid = {$departmentid} ";
	$sql .= " ORDER BY program ";

	$rows = fetch_all_rows($sql);

	foreach ($rows as $result) {

		echo "<option value='{$result['programid']}'>";
		echo "{$result['program']}";
		echo "</option>";

	}

		
?>