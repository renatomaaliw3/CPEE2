<?php

	include_once('../connection.php');
	include_once('../include/functions.php');
	include_once('../include/pagination.php');

	$limit = 3;
	$page = get_page_value();

	$sql = "SELECT * FROM tblemployees ";

		$sql .= " INNER JOIN tbldepartment ON ";
		$sql .= " tblemployees.departmentid = tbldepartment.departmentid ";

		$sql .= " INNER JOIN tblprogram ON ";
		$sql .= " tblemployees.programid = tblprogram.programid ";

	$sql .= " ORDER BY lastname, firstname, department, sex ";

	$sql_pagination = pagination_sql($page, $limit, $sql);

	echo $sql_pagination;

	$rows = fetch_all_rows($sql_pagination);
	$total_records = count_rows($sql);

	if ($total_records > 0) {

		echo "<table>";
			echo "<tr>";
			echo "<th> Last Name </th>";
			echo "<th> First Name </th>";
			echo "<th> Middle Name </th>";
			echo "<th> Sex </th>";
			echo "<th> Department </th>";
			echo "<th> Program </th>";
			echo "<th colspan='3'> Action </th>";
		echo "</tr>";

		foreach ($rows as $result) {

			echo "<tr>";
				echo "<td>" . $result['lastname'] . "</td>";
				echo "<td>" . $result['firstname'] . "</td>";
				echo "<td>" . $result['middlename'] . "</td>";
				echo "<td>" . $result['sex'] . "</td>";
				echo "<td>" . $result['department'] . "</td>";
				echo "<td>" . $result['program'] . "</td>";
				echo "<td><a href='update.php?employeeid={$result['employeeid']}'> UPDATE </a>";
				echo "<td><a href=\"delete.php?employeeid={$result['employeeid']}\" onclick=\"return confirm('Are you Sure?')\"> DELETE </a>";
				echo "<td><a href='#' data-employeeid='{$result['employeeid']}' class='view-info'> VIEW </a>";
			echo "</tr>";

		}

		echo "</table>";

		echo "<div id='pagination-container'>";
			
			echo "<ul class='pagination' id='pagination'>";

				echo pagination_links($total_records, $limit, $page);

			echo "</ul>";

		echo "</div>";

	} else {

		echo "<h3> No Records Found or Database is Empty! </h3>";

	}

		
?>