<?php  

/* PAGINATION FUNCTIONS */

function pagination_links($total_records, $limit, $page) {

	$output = '';

	$total_pages = ceil($total_records / $limit);

	for ($i = 1; $i <= $total_pages; $i++) {

		if ($i == 1) {

			$output .= show_tracker_links($total_pages, 'first', $page);
			$output .= "<li><a href='#' " . show_current_page_link($i, $page) .  "data-page='" . $i . "'>" . $i . "</a></li>";

		} else {

			if ($i == $total_pages) {

				$output .= "<li><a href='#' " . show_current_page_link($i, $page) .  "data-page='" . $i . "'>" . $i . "</a></li>";
				$output .= show_tracker_links($total_pages, 'last', $page);

			} else {

				$output .= "<li><a href='#' " . show_current_page_link($i, $page) .  "data-page='" . $i . "'>" . $i . "</a></li>";
				
			}

		}

	}

	return $output;

}

function get_page_value() {

	if (!isset($_GET['page'])) { //if page is not set

		$page = 1;

	} else {

		$page = $_GET['page']; // if page is set 

	}

	return $page;

}

function pagination_sql($page, $limit, $sql) {

	$start = ($page - 1) * $limit;

	$sql = $sql;
	$sql .= " LIMIT {$start}, {$limit}";

	return $sql;

}

function show_current_page_link($i, $page) {

	$output = '';

	if ($i == $page) {

		$output = " class='current-page' ";

	}

	return $output;

}

function show_tracker_links($total_pages, $mode, $page) {

	$output = '';

	switch ($mode) {

		case 'first':

			if ($page != 1) {

				$output = "<li><a href='#' class='first-page' data-page='1'> First </a></li>";
				$output .= "<li><a href='#' data-page='" . show_prev_page($page)  . "'> &laquo; </a></li>";
					
			} else { //if page number is 1, disable

				$output = "<li><span class='disabled'> First </span></li>";
				$output .= "<li><span class='disabled'> &laquo; </span></li>";

			}

		break;

		default:

			if ($page != $total_pages) {

				$output .= "<li><a href='#' data-page='" . show_next_page($page, $total_pages)  . "'> &raquo; </a></li>";
				$output .= "<li><a href='#' class='last-page' data-page={$total_pages}'> Last </a></li>";;
					
			} else { //if page number is equal total pages, disable

				$output .= "<li><span class='disabled'> &raquo; </span></li>";
				$output .= "<li><span class='disabled'> Last </span></li>";
					
			}

	}

	return $output;

}

function show_prev_page($page) { //tracker for previous page

	$page = $page - 1;

	if ($page < 1) { //if page is less than 0, set page again to 1

		$page = 1;

	}

	return $page;

}

function show_next_page($page, $total_pages) { // tracker for next page

	$page = $page + 1;

	if ($page > $total_pages) { //if page exceeds the calculated total page, set page again to total page

		$page = $total_pages;

	}

	return $page;

}


?>