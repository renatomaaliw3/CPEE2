<?php 

	include('connection.php');
	include('include/functions.php');

?>
<!DOCTYPE html>
<html>
	<head>
		<title> Simple CRUD Application (Dropdown, Radio)</title>
		<link rel="stylesheet" href="css/styles.css">
	</head>
<body>

	<div id="wrapper">

		<?php

			$employeeid = $_GET['employeeid'];

			$sql = "SELECT * FROM tblemployees WHERE employeeid = :employeeid ";

			$result = fetch_single_row($sql, 'employeeid', $employeeid);

			if (isset($_POST['update'])) {

				array_pop($_POST); //remove 'update' post

				execute_query('tblemployees', $_POST, 'update', 'employeeid', $employeeid);

				redirect_to('index.php');

			}

		?>

		<form action="#" method="post" id="add">
			
			<fieldset>
				<legend> Update Record </legend>
				<div>
					<label for="lastname"> Last Name </label>
					<input type="text" name="lastname" id="lastname" required value="<?php echo $result['lastname']; ?>">
				</div>
				<div>
					<label for="middlename"> Middle Name </label>
					<input type="text" name="middlename" id="middlename" required value="<?php echo $result['middlename']; ?>">
				</div>
				<div>
					<label for="firstname"> First Name </label>
					<input type="text" name="firstname" id="firstname" required value="<?php echo $result['firstname']; ?>">
				</div>
				<div>
					<label for="sex"> Sex </label>
					<p>
						<input type="radio" name="sex" value="Male" required <?php echo $result['sex'] == 'Male' ? 'checked' : ''; ?>><span> Male </span>
						<input type="radio" name="sex" value="Female" required <?php echo $result['sex'] == 'Female' ? 'checked' : ''; ?>><span> Female </span>
					</p>
				</div>
				<div>
					<label for="departmentid"> Department </label>
					<select name="departmentid" id="departmentid" required>
						
						<?php

							$sql = "SELECT * FROM tbldepartment ORDER BY department";

							echo bindDropdown($sql, 'departmentid', 'department', $result['departmentid']);

						?>

					</select>
				</div>
				<div>
					<label for="programid"> Program </label>
					<select name="programid" id="programid" required>
						
						<?php

							$sql = "SELECT * FROM tblprogram WHERE departmentid = {$result['departmentid']} ORDER BY program";

							echo bindDropdown($sql, 'programid', 'program', $result['programid']);

						?>

					</select>
				</div>
				<div>
					<label for=""> &nbsp;</label>
					<input type="submit" value="UPDATE" name="update">
				</div>

			</fieldset>
			
		</form>
		
	</div>

</body>
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/main.js"></script>
</html>