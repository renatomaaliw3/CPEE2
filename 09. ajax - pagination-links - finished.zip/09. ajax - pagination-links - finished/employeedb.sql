-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2019 at 09:33 AM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `employeedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbldepartment`
--

CREATE TABLE `tbldepartment` (
  `departmentid` int(5) NOT NULL,
  `department` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbldepartment`
--

INSERT INTO `tbldepartment` (`departmentid`, `department`) VALUES
(1, 'College of Engineering'),
(2, 'College of Agriculture'),
(3, 'College of Allied Medicine'),
(4, 'College of Business Administration'),
(5, 'College of Arts and Sciences'),
(6, 'College of Teacher Education');

-- --------------------------------------------------------

--
-- Table structure for table `tblemployees`
--

CREATE TABLE `tblemployees` (
  `employeeid` int(11) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `middlename` varchar(75) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `sex` varchar(6) NOT NULL,
  `departmentid` int(5) NOT NULL,
  `programid` int(11) NOT NULL,
  `photo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblemployees`
--

INSERT INTO `tblemployees` (`employeeid`, `lastname`, `middlename`, `firstname`, `sex`, `departmentid`, `programid`, `photo`) VALUES
(38, 'Maaliw', 'Racelis', 'Renato III', 'Male', 1, 3, '3422241225dd39a0a7549a5.12142262342224122.jpg'),
(39, 'Esperal', 'Cadao', 'Marissa', 'Female', 5, 22, '686340345dd39a004e9251.0321762868634034.jpg'),
(41, 'Pavino', 'Racelis', 'Leonard Allen', 'Male', 1, 3, '2104187025dd39a15c50925.67185855210418702.jpg'),
(42, 'Almazol', 'A.', 'Amalia', 'Female', 2, 8, ''),
(43, 'Sabacco', 'Riego', 'Fatima', 'Female', 4, 15, ''),
(44, 'Mendoza', 'Encomienda', 'Angelo Shan', 'Male', 4, 15, ''),
(45, 'Lajara', 'Nayro', 'Bernadette', 'Female', 4, 15, ''),
(46, 'Mecija', 'Buctil', 'Evangeline', 'Female', 3, 11, ''),
(47, 'Tan', 'Ella', 'John', 'Male', 1, 7, ''),
(48, 'Marqueses', 'Saludes', 'Jed Franklin', 'Male', 5, 19, '');

-- --------------------------------------------------------

--
-- Table structure for table `tblprogram`
--

CREATE TABLE `tblprogram` (
  `programid` int(11) NOT NULL,
  `departmentid` int(11) NOT NULL,
  `program` varchar(75) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblprogram`
--

INSERT INTO `tblprogram` (`programid`, `departmentid`, `program`) VALUES
(2, 1, 'BS Civil Engineering'),
(3, 1, 'BS Computer Engineering'),
(4, 1, 'BS Electrical Engineering'),
(5, 1, 'BS Electronics Engineering'),
(6, 1, 'BS Industrial Engineering'),
(7, 1, 'BS Mechanical Engineering'),
(8, 2, 'BS Agriculture'),
(9, 2, 'BS Forestry'),
(10, 2, 'BS Environmental Science'),
(11, 3, 'BS Nursing'),
(12, 3, 'Midwifery'),
(13, 4, 'BS Accounting'),
(14, 4, 'BS Business Administration'),
(15, 4, 'BS Hospitality Management'),
(16, 4, 'BS Public Administration'),
(17, 5, 'BA Communication'),
(18, 5, 'BS Biology'),
(19, 5, 'BS Mathematics'),
(20, 6, 'BS Secondary Education'),
(21, 6, 'BS Elementary Education'),
(22, 5, 'AB Psychology'),
(23, 6, 'BS Physical Education');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbldepartment`
--
ALTER TABLE `tbldepartment`
  ADD PRIMARY KEY (`departmentid`);

--
-- Indexes for table `tblemployees`
--
ALTER TABLE `tblemployees`
  ADD PRIMARY KEY (`employeeid`),
  ADD KEY `departmentid` (`departmentid`);

--
-- Indexes for table `tblprogram`
--
ALTER TABLE `tblprogram`
  ADD PRIMARY KEY (`programid`),
  ADD KEY `departmentid` (`departmentid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbldepartment`
--
ALTER TABLE `tbldepartment`
  MODIFY `departmentid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tblemployees`
--
ALTER TABLE `tblemployees`
  MODIFY `employeeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT for table `tblprogram`
--
ALTER TABLE `tblprogram`
  MODIFY `programid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblemployees`
--
ALTER TABLE `tblemployees`
  ADD CONSTRAINT `tblemployees_ibfk_1` FOREIGN KEY (`departmentid`) REFERENCES `tbldepartment` (`departmentid`) ON UPDATE CASCADE;

--
-- Constraints for table `tblprogram`
--
ALTER TABLE `tblprogram`
  ADD CONSTRAINT `tblprogram_ibfk_1` FOREIGN KEY (`departmentid`) REFERENCES `tbldepartment` (`departmentid`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
