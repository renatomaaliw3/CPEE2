<?php

	function bindDropdown($sql, $value, $description, $identifier = NULL) {

		global $conn;

		$stmt = $conn->prepare($sql);

		$stmt->execute();

		$output = '';

		while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {

			$output .= "<option value='{$result[$value]}' ";

				if ($result[$value] == $identifier) {

					$output .= " selected ";

				}


			$output .= ">" . $result[$description] . "</option>";

		}

		return $output;

	}

	function redirect_to($location) {

		header("Location: " . $location);

	}

	function insert_data($table_name, $post_data) {

		global $conn;

		$sql = "INSERT INTO {$table_name} (" . getDBFields($post_data) . ") VALUES (" . getTokens($post_data) . ")";

		$stmt = $conn->prepare($sql);

		foreach ($post_data as $key => $value) {

			bindTokens($stmt, $key, $value);

		}
	
		$stmt->execute();

	}

		function getDBFields($post_data) {

			$sql = implode(', ', array_keys($post_data)); //array -> string

			return $sql;

		}

		function getTokens($post_data) {

			$new_array = array(); //define blank array

			$output = '';

			foreach ($post_data as $key => $value) {

				array_push($new_array, ":" . $key);

			}

			$output = implode(', ', $new_array);

			return $output;

		}

		function bindTokens($stmt, $key, $value) {

			return $stmt->bindParam(":" . $key, $value, PDO::PARAM_STR);

		}

?>