<?php 

	include('connection.php');
	include('include/functions.php');

?>
<!DOCTYPE html>
<html>
	<head>
		<title> Simple CRUD Application (Dropdown, Radio)</title>
		<link rel="stylesheet" href="css/styles.css">
	</head>
<body>

	<div id="wrapper">

		<?php

			$employeeid = $_GET['employeeid'];

			$sql = "SELECT * FROM tblemployees WHERE employeeid = :employeeid ";

			$stmt = $conn->prepare($sql);

			$stmt->bindParam(":employeeid", $employeeid, PDO::PARAM_INT);

			$stmt->execute();

			$result = $stmt->fetch(PDO::FETCH_ASSOC);

			if (isset($_POST['update'])) {

				$firstname = $_POST['firstname'];
				$lastname = $_POST['lastname'];
				$sex = $_POST['sex'];
				$departmentid = $_POST['departmentid'];

				$sql = "UPDATE tblemployees SET firstname = :firstname, lastname = :lastname, sex = :sex, departmentid = :departmentid ";
				$sql .= " WHERE employeeid = :employeeid";

				$stmt = $conn->prepare($sql);

				$stmt->bindParam(":employeeid", $employeeid, PDO::PARAM_INT);
				$stmt->bindParam(":firstname", $firstname, PDO::PARAM_STR);
				$stmt->bindParam(":lastname", $lastname, PDO::PARAM_STR);
				$stmt->bindParam(":sex", $sex, PDO::PARAM_STR);
				$stmt->bindParam(":departmentid", $departmentid, PDO::PARAM_STR);

				$stmt->execute();


				header("Location: index.php");

			}

		?>

		<form action="#" method="post">
			
			<fieldset>
				<legend> Update Record </legend>
				<div>
					<label for="firstname"> First Name </label>
					<input type="text" name="firstname" id="firstname" required value="<?php echo $result['firstname']; ?>">
				</div>
				<div>
					<label for="lastname"> Last Name </label>
					<input type="text" name="lastname" id="lastname" required value="<?php echo $result['lastname']; ?>">
				</div>
				<div>
					<label for="sex"> Sex </label>
					<p>
						<input type="radio" name="sex" value="Male" required <?php echo $result['sex'] == 'Male' ? 'checked' : ''; ?>><span> Male </span>
						<input type="radio" name="sex" value="Female" required <?php echo $result['sex'] == 'Female' ? 'checked' : ''; ?>><span> Female </span>
					</p>
				</div>
				<div>
					<label for="department"> Department </label>
					<select name="departmentid" id="departmentid" required>
						
						<?php

							$sql = "SELECT * FROM tbldepartment ORDER BY department";

							echo bindDropdown($sql, 'departmentid', 'department', $result['departmentid']);

						?>

					</select>
				</div>
				<div>
					<label for=""> &nbsp;</label>
					<input type="submit" value="UPDATE" name="update">
				</div>

			</fieldset>
			
		</form>
		
	</div>

</body>
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/main.js"></script>
</html>