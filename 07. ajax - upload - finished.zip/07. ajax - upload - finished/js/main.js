var request = null;
$(document).ready(function() {

	$('#employee-table').load('ajax/load_table.php');

	$('#search').on('keyup', function() {

		var search = $(this).val();

		if (request) {

			clearTimeout(request);

		}

		request = setTimeout(function() {

			$.ajax({

				method: 'POST',
				url: 'ajax/load_search.php',
				data: {search : search},
				success: function(data) {

					$('#employee-table').html(data);
					request = null;

				}

			});

		}, 1000);

	});


	$('#departmentid').on('change', function() {

		var departmentid = $(this).val();

		$.ajax({

			method: 'POST',
			url: 'ajax/load_program.php',
			data: {departmentid : departmentid},
			success: function(data) {

				$('#programid').html(data);
				$('#programid').prop('disabled', false);


			}

		});

	});

	$('#employee-table').on('click', '.view-info', function(event) {

		event.preventDefault();

		var employeeid = $(this).attr('data-employeeid');

		$('#overlay').load('ajax/load_view_form.php?employeeid=' + employeeid).fadeIn();


	});

	$('#overlay').on('click', '.close', function() {

		$(this).parents('#overlay').fadeOut();

	});

});