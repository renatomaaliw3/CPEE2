<?php

	include_once('../connection.php');
	include_once('../include/functions.php');

	$search = $_POST['search'];
	
	$sql = "SELECT * FROM tblemployees ";
	$sql .= " INNER JOIN tbldepartment ON ";
	$sql .= " tblemployees.departmentid = tbldepartment.departmentid ";

	$sql .= " WHERE CONCAT_WS(' ', lastname, firstname, middlename, sex, department) LIKE '%" . $search . "%'";

	$sql .= " ORDER BY lastname, firstname, department, sex";

	$rows = fetch_all_rows($sql);
	$count = count_rows($sql);

	if ($count > 0) {

		echo "<p><em> There are " . $count . " match/es found </em></p>";

		echo "<table>";
			echo "<tr>";
			echo "<th> Last Name </th>";
			echo "<th> First Name </th>";
			echo "<th> Middlename </th>";
			echo "<th> Sex </th>";
			echo "<th> Department </th>";
			echo "<th colspan='2'> Action </th>";
		echo "</tr>";

		foreach ($rows as $result) {

			echo "<tr>";
				echo "<td>" . $result['lastname'] . "</td>";
				echo "<td>" . $result['firstname'] . "</td>";
				echo "<td>" . $result['middlename'] . "</td>";
				echo "<td>" . $result['sex'] . "</td>";
				echo "<td>" . $result['department'] . "</td>";
				echo "<td><a href='update.php?employeeid={$result['employeeid']}'> UPDATE </a>";
				echo "<td><a href=\"delete.php?employeeid={$result['employeeid']}\" onclick=\"return confirm('Are you Sure?')\"> DELETE </a>";
			echo "</tr>";

		}

		echo "</table>";

	} else {

		echo "<h3> No Records Found! </h3>";

	}

		
?>