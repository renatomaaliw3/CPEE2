<?php

	function bindDropdown($sql, $value, $description, $identifier = NULL) {

		global $conn;

		$stmt = $conn->prepare($sql);

		$stmt->execute();

		$output = '';

		while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {

			$output .= "<option value='{$result[$value]}' ";

				if ($result[$value] == $identifier) {

					$output .= " selected ";

				}


			$output .= ">" . $result[$description] . "</option>";

		}

		return $output;

	}


?>