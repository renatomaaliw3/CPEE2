<?php

	require('connection.php');
	include('include/functions.php');

	$employeeid = $_GET['employeeid'];

	execute_query('tblemployees', NULL, 'delete', 'employeeid', $employeeid);

	//redirect_to('index.php');

?>